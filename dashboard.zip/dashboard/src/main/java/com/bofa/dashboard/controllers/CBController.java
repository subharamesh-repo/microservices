package com.bofa.dashboard.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.bofa.dashboard.dto.JwtRequest;
import com.bofa.dashboard.handlers.HystrixHandler;

@RestController
public class CBController {
    @Autowired 
	private HystrixHandler hystrixHandler;
	
	@PostMapping("/cbcustomers")
	public ResponseEntity<?> getCustomers(@RequestBody JwtRequest jwtRequest)
	{
		ResponseEntity<String> response=hystrixHandler.requestHandler(jwtRequest);
		
		if(response.getBody().isEmpty())
			
	       return ResponseEntity.status(HttpStatus.BAD_REQUEST).body("Call not connected");
		else
			return response;
		
	}
}
