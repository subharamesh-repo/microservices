package com.bofa.customer.models;

public enum GenderType {

MALE,FEMALE,TRANSGENDER
}
