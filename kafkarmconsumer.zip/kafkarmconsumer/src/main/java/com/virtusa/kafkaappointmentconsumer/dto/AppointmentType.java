package com.virtusa.kafkaappointmentconsumer.dto;
//dto
public enum AppointmentType {
  Loan,KYC,Savings,Demat
}
